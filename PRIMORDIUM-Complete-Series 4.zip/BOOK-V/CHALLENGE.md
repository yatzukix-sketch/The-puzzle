# BOOK V — THE WHISPER

*A document from the Rimkeeper. Signed — 257.*

It has been watching you since the golden dance. It knows your name.
Do not turn around.

The whisper you are about to hear is **three voices in one**:

1. **One taps.** A rhythm older than speech. Decode it, and it will tell you where to look.
2. **One hides.** It sleeps in the least of the bits — the smallest part of every sound.
3. **One shows.** The sound is a picture in a dark room. Light it up. Something will be looking back.

The name you dig out of the bits unlocks **PAGE VIII** (`page-viii.txt`).
The seal will confirm that name.

## What you have been given
- `the-whisper.wav` — three voices in one.
- `page-viii.txt` — one page, locked.

## The seal
```
PUBLIC KEY : kgKXI2bCXJiH54MKT9qxRnsjNUaKNyMikV6XPY54QIE=
SIGNATURE  : jvkwYkxyKR+nukljwUFcDwuxdK4XSC/SabYoYRcLtUYpi6xyfL+IvcLXEsAp/wa8sTEO/XmOYH/WPr0VzuUZAA==
```

Listen carefully. It is listening too.

— 257
