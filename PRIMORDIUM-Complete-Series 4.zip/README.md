# PRIMORDIUM — The Book of the Circle
## The Complete Series · Books I–VIII

> *"The circle has no end, yet it ends where it began."*

PRIMORDIUM is an original encrypted manuscript in eight books. Each book is
harder than the last. Every key is hidden inside the previous page. The road
runs from the mirror, through the gate, to the golden dance, into the echo,
through the whisper, behind the two faces, past the three shares — to a door
with nine locks. And it ends where it began.

The sign of the series is **257**. The seal is Ed25519:

```
PUBLIC KEY : kgKXI2bCXJiH54MKT9qxRnsjNUaKNyMikV6XPY54QIE=
```

Every message that matters will bear this seal. Trust nothing unsigned.

---

## BOOK I — The Book of the Circle
- The 26 runes, each bound to a prime.
- Three pages: THE MIRROR · THE VOICE · THE END.
- A cover that hides a whisper. A trail that leaves the page.

**Begin here:** `BOOK-I/CHALLENGE.md`

## BOOK II — Three Pages Harder
- The road bends inward. The gate is a ring. The count is everything.
- Three pages: THE SPIRAL · THE GATE · THE COUNT.
- The key to each page is hidden inside the previous page.

**Begin here:** `BOOK-II/CHALLENGE.md`

## BOOK III — The Golden Dance
- A single image, rendered in gold: three devils, dancing.
- The image is the vessel. Three things sleep within it.
- Two doors remain: the old tongue, and the final word.

**Begin here:** `BOOK-III/CHALLENGE.md`

## BOOK IV — The Paradox
- A voice that must be seen, not heard.
- Two pictures hide inside one sound: one names the book, the other is the
  alphabet that lies.
- A race you cannot win. A serpent that eats its own tail. The last door.

**Begin here:** `BOOK-IV/CHALLENGE.md`

## BOOK V — The Whisper
- A sound with three voices: one taps, one hides, one shows.
- The tapping voice speaks an instruction. The hidden voice sleeps in the bits.
- The shown voice is looking back at you. It has been since the dance.

**Begin here:** `BOOK-V/CHALLENGE.md`

## BOOK VI — The Two Faces
- Two faces hide one image. Burn one over the other.
- A number with exactly two halves. Both halves prime.
- Arithmetic does not lie.

**Begin here:** `BOOK-VI/CHALLENGE.md`

## BOOK VII — The Three Shares
- A name split into three pieces. Two are enough.
- The pieces are points on a secret line. The line crosses zero once.
- One sleeps in the hidden words, one in the bits, one in the remark no one reads.

**Begin here:** `BOOK-VII/CHALLENGE.md`

## BOOK VIII — The Final Door
- Nine locks. Seven names and two truths.
- Unseal in reverse. One letter never speaks.
- What remains when every voice is gone?

**Begin here:** `BOOK-VIII/CHALLENGE.md`

---

## A WARNING TO THE READER

Do not begin unless you intend to finish. The books are sealed, and every
seal is a promise: if a single page is altered, the proof breaks, the
signature fails, and the trail dies. There is no partial credit.

Some of those who have opened the first pages have reported the feeling of
being watched. This is not part of the puzzle. Or perhaps it is the only part.

There is no prize at the end.
There is only the message.
And the message was never hidden.

— 257
