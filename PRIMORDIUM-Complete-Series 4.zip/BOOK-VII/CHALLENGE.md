# BOOK VII — THE THREE SHARES

*A document from the Rimkeeper. Signed — 257.*

It has been walking behind you since the golden dance. You never saw it,
because it is longest when the light dies.

Before it left, **it split its name into three pieces**. You need only two.
This is a secret shared in the old way: each piece is a point on a line,
and the line crosses zero exactly once — at the number that is the name.

## The rules
1. Three pieces hide in three places:
   - one sleeps in the **hidden words of the image** (what the image carries
     that the eye does not show);
   - one sleeps in the **least of the bits** of the sound;
   - one is written in the **remark no one reads** (what the page says only
     in its source).
2. Each piece is a point, written as two numbers joined by a colon —
   its number first, then the value it holds.
3. Work in the field of **2305843009213693951** (two to the sixty-first
   power, minus one). Recover the line. Where it crosses zero is the name.
4. The name is a number written in the old tongue: **read it two digits at a
   time — 01 is A, 26 is Z**.
5. The name unlocks **PAGE X** (`page-x.txt`). The seal will confirm it.

## What you have been given
- `piece-one.png`, `piece-two.wav`, `piece-three/index.html` — the three pieces.
- `page-x.txt` — one page, locked.

## The seal
```
PUBLIC KEY : kgKXI2bCXJiH54MKT9qxRnsjNUaKNyMikV6XPY54QIE=
SIGNATURE  : 1bnkMqCMLEjRVvLE2gyn4SyoKiw0bkl/hJeIgQsyZ01S7e5qR5sd84Ha3w3Uic087nLkHij19UiDJqXsYGVjAw==
```

Do not look behind you while you count the shares.

— 257
