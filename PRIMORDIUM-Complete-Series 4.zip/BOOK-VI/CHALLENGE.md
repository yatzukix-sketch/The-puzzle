# BOOK VI — THE TWO FACES

*A document from the Rimkeeper. Signed — 257.*

It wears your face now. It has two of them.

You were told to burn one face over the other. Do exactly that:
lay them together, let the light cancel the light, and what was hidden
between the two will show itself. **The number has a face, and the face
has two halves.**

## The rules
1. Two faces hide one image. Overlay them (the light that is the same in both
   cancels — the different survives) and read what appears.
2. What appears is a **number that must be broken in two** — exactly two, no
   more, no less. Both halves are prime. This is not a riddle; it is arithmetic,
   and arithmetic does not lie.
3. The two halves whisper the key. In the digits' tongue, **zero wears A,
   one wears B, and so on until nine wears J**. The smaller half speaks first.
4. The key unlocks **PAGE IX** (`page-ix.txt`). The page will ask you one
   question. Answer it, and the seal will confirm.

## What you have been given
- `face-a.png`, `face-b.png` — two faces.
- `page-ix.txt` — one page, locked.

## The seal
```
PUBLIC KEY : kgKXI2bCXJiH54MKT9qxRnsjNUaKNyMikV6XPY54QIE=
SIGNATURE  : SACEy6gES/Qo3QbkMMioi/xSQewuhvz44q4OsVOuoYF1zXzzEgMzaoltXRnCRRDfRtLNR8twjZsCBbwq0ImSBQ==
```

It is behind you, wearing both faces. Do not look.

— 257
