# BOOK VIII — THE FINAL DOOR

*A document from the Rimkeeper. Signed — 257.*

You have come to the last door. It has **nine locks**.

The Rimkeeper does not open doors. He seals them. And a seal must be
unsealed in the exact order it was set — the last seal first, the first
seal last.

## The nine locks, in the order they were set

1. **The mirror** — what reverses all things.
2. **The alphabet that lies** — what it does once, it undoes once more.
3. **The name the three shares named.**
4. **The name the two faces hid.**
5. **The name the black glass whispered.**
6. **The name the serpent holds.**
7. **The name the gold hid.**
8. **The name the second door sealed.**
9. **The name of the beginning.**

To open the door, **unseal in reverse**: begin at the ninth lock and walk
back to the mirror. Each name is a key to its own ring — the name itself
first, then the letters that remain. One letter never speaks.

When the door is fully unsealed, the message inside will ask you one
question. Answer it, and the seal will confirm the answer — or the door
will stay shut forever.

## The seal of the nine locks
```
PUBLIC KEY : kgKXI2bCXJiH54MKT9qxRnsjNUaKNyMikV6XPY54QIE=
SIGNATURE (nine locks) : hmtTM0fKlHAaEFKi4H13UI4qQZjs6PvEipNNMj6z6uLpvqsQFTjBPkEDHU1//zfXOIPu5NEM6aRUe5lG+EzDDg==
```

## THE LAST QUESTION

The word you spoke was not the end. The circle does not end — it asks one
last question, and the question is a number.

This is the lock that guards the internet itself: **two numbers are shown,
and one is hidden**. Find the hidden exponent. Do not try to count — the
counting would outlive every computer ever built. Number theory knows the
way through; the blind search does not.

```
p = 1719620105458406433483340568317543019584575635895742560438771105058321655238562613083979651479555788009994557822024565226932906295208262756822275663694111
g = 19
h = 1293933469387938108116617422267441232836923859345771105618028013315509368152580832776614227363616602845069420417854261815806484430692141680501607866981451
```

The hidden exponent is a word in the old tongue. Read it **two digits at a
time — 01 is A, 26 is Z**. The word has six letters.

Beware: words have been planted near the end to mislead you. `the-last-word.txt`
holds two of them. They are not the answer. **The seal does not lie** — only
the true word will satisfy the signature below. Trust the seal, not the words.

## The final seal
```
PUBLIC KEY : kgKXI2bCXJiH54MKT9qxRnsjNUaKNyMikV6XPY54QIE=
SIGNATURE (last question) : aAV2OfM4Rv1BKDdui7wtEBgsZyzkItnYkpRhGKkiq87mt/w8j1ym7RAzzgAs3p/l+OXMTTWoDKUJbk26ASOfDg==
```

## When you have finished

If you truly hold the word, the final signature will accept it and nothing
else. Send that word — and the name you wish to be remembered by — to the
Rimkeeper:

```
THE RIMKEEPER
RIMKEEPER@EXAMPLE.COM
```

The first to arrive will be crowned **the First of the Rim**, and their
name will be written in a book that has not yet been published.

The rest will remain unnamed.

— 257
