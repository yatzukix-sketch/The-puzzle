# PRIMORDIUM — Book III: THE GOLDEN DANCE
## A Challenge for the Decoder

> *“Three devils dance in gold. What they circle, you cannot see.”*

You have walked the spiral, the gate, and the count. You spoke the word and the
seal answered. Now the road bends one last time — into a single image.

There is no page here. There is only a **vessel**.

---

## THE VESSEL

`devils_gold.png` — an image, rendered in gold, bearing the sign **257**.

The image is not the message. The image carries the message. Three things are
hidden within it:

1. A **key**, sleeping where the eye never looks.
2. A **cipher**, written on the vessel itself.
3. A **question**, for those who can read.

---

## THE DOORS

### DOOR 4 — THE GOLDEN DANCE (the link)
> “The key sleeps in the least of the pixels.
> The cipher is written on the vessel itself.”

Find the key. Find the cipher. The cipher is a ring that has been reordered —
and one letter never speaks.

### DOOR 5 — THE OLD TONGUE
> “Speak the name of gold in the old tongue, and use it to open the end.”

The plaintext asks you a single question about gold. Answer it in the language
of the ancients.

### DOOR 6 — THE FINAL DOOR
> “What has no sides, no end, and no gold, yet holds all things?”

The final word is guarded by a cryptographic seal (Ed25519):

```
PUBLIC KEY : kgKXI2bCXJiH54MKT9qxRnsjNUaKNyMikV6XPY54QIE=
```

If you can speak the word, the seal proves you were here.

---

## WHAT TO DELIVER

1. The key hidden in the vessel (where was it?).
2. The full plaintext of the cipher (and the name of the cipher system).
3. The name of gold in the old tongue.
4. The final word, verified against the seal.

*“The road ends where it began.”*

— 257
