# PRIMORDIUM — The Book of the Circle
## The Complete Series · Books I–IV

> *"The circle has no end, yet it ends where it began."*

PRIMORDIUM is an original encrypted manuscript in four books. Each book is
harder than the last. Every key is hidden inside the previous page. The road
runs from the mirror, through the gate, to the golden dance, and into the echo —
and it ends where it began.

The sign of the series is **257**. The seal is Ed25519:

```
PUBLIC KEY : kgKXI2bCXJiH54MKT9qxRnsjNUaKNyMikV6XPY54QIE=
```

Every message that matters will bear this seal. Trust nothing unsigned.

---

## BOOK I — The Book of the Circle
- The 26 runes, each bound to a prime.
- Three pages: THE MIRROR · THE VOICE · THE END.
- A cover that hides a whisper. A trail that leaves the page.

**Begin here:** `BOOK-I/CHALLENGE.md`

## BOOK II — Three Pages Harder
- The road bends inward. The gate is a ring. The count is everything.
- Three pages: THE SPIRAL · THE GATE · THE COUNT.
- The key to each page is hidden inside the previous page.

**Begin here:** `BOOK-II/CHALLENGE.md`

## BOOK III — The Golden Dance
- A single image, rendered in gold: three devils, dancing.
- The image is the vessel. Three things sleep within it.
- Two doors remain: the old tongue, and the final word.

**Begin here:** `BOOK-III/CHALLENGE.md`

## BOOK IV — The Paradox
- A voice that must be seen, not heard.
- Two pictures hide inside one sound: one names the book, the other is the
  alphabet that lies.
- A race you cannot win. A serpent that eats its own tail. The last door.

**Begin here:** `BOOK-IV/CHALLENGE.md`

---

There is no prize at the end.
There is only the message.
And the message was never hidden.

— 257
