# BOOK IV — THE PARADOX

*A document from the Rimkeeper. Signed — 257.*

The fourth book does not ask you to read. It asks you to **listen**.
Close your eyes. What do you see?

## What you have been given
- `the-echo.wav` — a voice. But the ear is not the right organ.
- `ciphertext.txt` — PAGE VII. One page only.
- `the-gate/index.html` — the last door.

## The rules (spoken, never written)
1. The sound is a picture in a dark room. **Light it up.**
2. Two pictures hide inside one voice. One names the book. The other is **the alphabet that lies**.
3. The lying alphabet: what it does once, it undoes once more. Read PAGE VII through it, and the truth appears.
4. The page will speak of a race you cannot win: before the end there is a half; before the half, another half. **You never arrive.**
5. The name of that race is the song that opens the last door — the same singing voice that carried the earlier pages.
6. Behind the door waits one final riddle: the serpent that eats its own tail is never hungry, yet never full.
7. Speak the serpent's name. The seal will confirm it.

## The seal
```
PUBLIC KEY : kgKXI2bCXJiH54MKT9qxRnsjNUaKNyMikV6XPY54QIE=
```
The final word is sealed. The proof is hashed. The rest is silence.

— 257
